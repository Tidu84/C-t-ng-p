/*
  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
  Copyright (C) 2004-2025 The Stockfish developers (see AUTHORS file)

  Stockfish is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Stockfish is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "search.h"

#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <deque>
#include <initializer_list>
#include <string>
#include <utility>

#include "evaluate.h"
#include "history.h"
#include "misc.h"
#include "movegen.h"
#include "movepick.h"
#include "abjnnue/abjnnue_network.h"
#include "position.h"
#include "thread.h"
#include "timeman.h"
#include "tt.h"
#include "uci.h"
#include "ucioption.h"

namespace Stockfish {

using namespace Search;

namespace {

constexpr int SEARCHEDLIST_CAPACITY = 32;
using SearchedList                  = ValueList<Move, SEARCHEDLIST_CAPACITY>;

// (*Scalers):
// The values with Scaler asterisks have proven non-linear scaling.
// They are optimized to time controls of 180 + 1.8 and longer,
// so changing them or adding conditions that are similar requires
// tests at these types of time controls.

int correction_value(const Worker& w, const Position& pos, const Stack* const ss) {
    const Color us    = pos.side_to_move();
    const auto  m     = (ss - 1)->currentMove;
    const auto  pcv   = w.pawnCorrectionHistory[pawn_structure_index<Correction>(pos)][us];
    const auto  micv  = w.minorPieceCorrectionHistory[minor_piece_index(pos)][us];
    const auto  wnpcv = w.nonPawnCorrectionHistory[non_pawn_index<WHITE>(pos)][WHITE][us];
    const auto  bnpcv = w.nonPawnCorrectionHistory[non_pawn_index<BLACK>(pos)][BLACK][us];
    const auto  cntcv =
      m.is_ok() ? (*(ss - 2)->continuationCorrectionHistory)[pos.piece_on(m.to_sq())][m.to_sq()]
                : 0;

    return 4897 * pcv + 4190 * micv + 8120 * (wnpcv + bnpcv) + 8324 * cntcv;
}

// Add correctionHistory value to raw staticEval and guarantee evaluation
// does not hit the tablebase range.
Value to_corrected_static_eval(const Value v, const int cv) {
    return std::clamp(v + cv / 131072, VALUE_MATED_IN_MAX_PLY + 1, VALUE_MATE_IN_MAX_PLY - 1);
}

void update_correction_history(const Position& pos,
                               Stack* const    ss,
                               Search::Worker& workerThread,
                               const int       bonus) {
    const Move  m  = (ss - 1)->currentMove;
    const Color us = pos.side_to_move();

    int nonPawnWeight = 129;

    workerThread.pawnCorrectionHistory[pawn_structure_index<Correction>(pos)][us]
      << bonus * 136 / 128;
    workerThread.minorPieceCorrectionHistory[minor_piece_index(pos)][us] << bonus * 88 / 128;
    workerThread.nonPawnCorrectionHistory[non_pawn_index<WHITE>(pos)][WHITE][us]
      << bonus * nonPawnWeight / 128;
    workerThread.nonPawnCorrectionHistory[non_pawn_index<BLACK>(pos)][BLACK][us]
      << bonus * nonPawnWeight / 128;

    if (m.is_ok())
        (*(ss - 2)->continuationCorrectionHistory)[pos.piece_on(m.to_sq())][m.to_sq()]
          << bonus * 114 / 128;
}

constexpr double FlipWinrateScaling = 360.83524;

const std::array<double, 2 * VALUE_MATE + 1> FlipScoreToWinrate = []() {
    std::array<double, 2 * VALUE_MATE + 1> table{};

    for (int value = -VALUE_MATE; value <= VALUE_MATE; ++value)
        table[std::size_t(value + VALUE_MATE)] =
          1.0 / (1.0 + std::exp(-double(value) / FlipWinrateScaling));

    return table;
}();

double flip_score_to_winrate(Value v) {
    v = std::clamp(v, -VALUE_MATE, VALUE_MATE);
    return FlipScoreToWinrate[std::size_t(v + VALUE_MATE)];
}

Value flip_winrate_to_score(double winrate) {
    constexpr double epsilon = 1e-9;
    winrate                  = std::clamp(winrate, epsilon, 1.0 - epsilon);
    double q                 = std::log(winrate / (1.0 - winrate));
    return std::clamp(static_cast<Value>(q * FlipWinrateScaling), VALUE_MATED_IN_MAX_PLY + 1,
                      VALUE_MATE_IN_MAX_PLY - 1);
}

// Add a small random component to draw evaluations to avoid 3-fold blindness
Value value_draw(size_t nodes) { return VALUE_DRAW - 1 + Value(nodes & 0x2); }
Value value_to_tt(Value v, int ply);
Value value_from_tt(Value v, int ply, int r40c);
void  update_pv(Move* pv, Move move, const Move* childPv);
void  update_continuation_histories(Stack* ss, Piece pc, Square to, int bonus);
void  update_quiet_histories(
  const Position& pos, Stack* ss, Search::Worker& workerThread, Move move, int bonus);
void update_all_stats(const Position& pos,
                      Stack*          ss,
                      Search::Worker& workerThread,
                      Move            bestMove,
                      Square          prevSq,
                      SearchedList&   quietsSearched,
                      SearchedList&   capturesSearched,
                      Depth           depth,
                      Move            TTMove,
                      int             moveCount);

ChasingRule chasing_rule(const OptionsMap& options) {
    return options["ChasingRule"] == "skyrule_Jieqi" ? CHASING_RULE_SKYRULE_JIEQI
                                                     : CHASING_RULE_GITHUB;
}

inline int configured_aggressive_level(const OptionsMap& options) {
#if defined(ABJCHESS_RELEASE)
    (void) options;
    return 3;
#else
    return int(options["AggressiveLevel"]);
#endif
}

}  // namespace

Key Search::observer_tt_key(Key positionKey, Color rootObserver) {
    constexpr Key WhiteObserverSalt = 0x243F6A8885A308D3ULL;
    constexpr Key BlackObserverSalt = 0x13198A2E03707344ULL;

    assert(rootObserver == WHITE || rootObserver == BLACK);
    return positionKey ^ (rootObserver == WHITE ? WhiteObserverSalt : BlackObserverSalt);
}

int Search::hidden_capture_candidates(const Position&          position,
                                      Color                    rootObserver,
                                      bool                     capturedDark,
                                      Position::RestPieceList& candidates) {
    if (!capturedDark || ~position.side_to_move() != rootObserver)
        return 0;

    return position.rest_pieces(position.side_to_move(), candidates);
}

Depth Search::chance_branch_depth(Depth depth, int branchIndex) {
    return depth <= 1 || branchIndex == 0 ? depth : depth - 1;
}

Search::ProbCutContext Search::probcut_context(Value probCutBeta,
                                               Depth nodeDepth,
                                               bool  capturedDark) {
    return {capturedDark ? std::min(probCutBeta + 64, VALUE_INFINITE - 1) : probCutBeta,
            std::max(nodeDepth - (capturedDark ? 6 : 5), 0)};
}

Reveal::Parameters Search::snapshot_reveal_parameters(const OptionsMap& options) {
#if defined(ABJCHESS_RELEASE)
    (void) options;
    // Release builds bake in the validated defaults and omit research UCI knobs.
    return {-12, 24, -12};
#else
    return {int(options["RevealQuietBase"]), int(options["RevealQuietSafety"]),
            int(options["RevealQuietHighValue"])};
#endif
}

Search::Worker::Worker(SharedState&                    sharedState,
                       std::unique_ptr<ISearchManager> sm,
                       size_t                          threadId,
                       NumaReplicatedAccessToken       token) :
    // Unpack the SharedState struct into member variables
    threadIdx(threadId),
    numaAccessToken(token),
    manager(std::move(sm)),
    options(sharedState.options),
    threads(sharedState.threads),
    tt(sharedState.tt),
    networks(sharedState.networks),
    refreshTable(networks[token]) {
    clear();
}

void Search::Worker::refresh_chasing_rule() {
    searchRule = chasing_rule(options);
    useSkyrule = searchRule == CHASING_RULE_SKYRULE_JIEQI;
}

void Search::Worker::ensure_network_replicated() {
    // Access once to force lazy initialization.
    // We do this because we want to avoid initialization during search.
    (void) (networks[numaAccessToken]);
}

void Search::Worker::start_searching() {

    refresh_chasing_rule();
    reset_correction_histories();
    revealParameters   = snapshot_reveal_parameters(options);
    quietRewardEnabled = Reveal::quiet_bonus_enabled(revealParameters);
    quietSafetyNeeded  = quietRewardEnabled;
    revealSearchTuning = quietSafetyNeeded;
    rootObserver       = rootPos.side_to_move();
    accumulatorStack.reset();
#if defined(ABJNNUE_RUNTIME_REFRESH_CACHE)
    refreshTable.clear(networks[numaAccessToken]);
#endif

    // Non-main threads go directly to iterative_deepening()
    if (!is_mainthread())
    {
        iterative_deepening();
        return;
    }

    main_manager()->tm.init(limits, rootPos.side_to_move(), rootPos.game_ply(), options,
                            main_manager()->originalTimeAdjust);
    tt.new_search();

    if (rootMoves.empty())
    {
        rootMoves.emplace_back(Move::none());
        main_manager()->updates.onUpdateNoMoves({0, {-VALUE_MATE, rootPos}});
    }
    else
    {
        threads.start_searching();  // start non-main threads
        iterative_deepening();      // main thread start searching
    }

    // When we reach the maximum depth, we can arrive here without a raise of
    // threads.stop. However, if we are pondering or in an infinite search,
    // the UCI protocol states that we shouldn't print the best move before the
    // GUI sends a "stop" or "ponderhit" command. We therefore simply wait here
    // until the GUI sends one of those commands.
    while (!threads.stop && (main_manager()->ponder || limits.infinite))
    { }  // Busy wait for a stop or a ponder reset

    // Stop the threads if not already stopped (also raise the stop if
    // "ponderhit" just reset threads.ponder)
    threads.stop = true;

    // Wait until all threads have finished
    threads.wait_for_search_finished();

    // When playing in 'nodes as time' mode, subtract the searched nodes from
    // the available ones before exiting.
    if (limits.npmsec)
        main_manager()->tm.advance_nodes_time(threads.nodes_searched()
                                              - limits.inc[rootPos.side_to_move()]);

    Worker* bestThread = this;

    if (int(options["MultiPV"]) == 1 && !limits.depth && rootMoves[0].pv[0] != Move::none())
        bestThread = threads.get_best_thread()->worker.get();

    main_manager()->bestPreviousScore        = bestThread->rootMoves[0].score;
    main_manager()->bestPreviousAverageScore = bestThread->rootMoves[0].averageScore;

    // Send again PV info if we have a new best thread
    if (bestThread != this)
        main_manager()->pv(*bestThread, threads, tt, bestThread->completedDepth);

    std::string ponder;

    if ((bestThread->rootMoves[0].pv.size() > 1
         || bestThread->rootMoves[0].extract_ponder_from_tt(tt, rootPos, rootObserver))
        && !rootPos.move_dark(bestThread->rootMoves[0].pv[0]))
        ponder = UCIEngine::move(bestThread->rootMoves[0].pv[1]);

    auto bestmove = UCIEngine::move(bestThread->rootMoves[0].pv[0]);
    main_manager()->updates.onBestmove(bestmove, ponder);
}

// Main iterative deepening loop. It calls search()
// repeatedly with increasing depth until the allocated thinking time has been
// consumed, the user stops the search, or the maximum search depth is reached.
void Search::Worker::iterative_deepening() {

    SearchManager* mainThread = (is_mainthread() ? main_manager() : nullptr);

    Move pv[MAX_PLY + 1];

    Depth lastBestMoveDepth = 0;
    Value lastBestScore     = -VALUE_INFINITE;
    auto  lastBestPV        = std::vector{Move::none()};

    Value  alpha, beta;
    Value  bestValue     = -VALUE_INFINITE;
    Color  us            = rootPos.side_to_move();
    double timeReduction = 1, totBestMoveChanges = 0;
    int    delta, iterIdx                        = 0;

    // Allocate stack with extra size to allow access from (ss - 7) to (ss + 2):
    // (ss - 7) is needed for update_continuation_histories(ss - 1) which accesses (ss - 6),
    // (ss + 2) is needed for initialization of cutOffCnt.
    Stack  stack[MAX_PLY + 10] = {};
    Stack* ss                  = stack + 7;

    for (int i = 7; i > 0; --i)
    {
        (ss - i)->continuationHistory =
          &this->continuationHistory[0][0][NO_PIECE][0];  // Use as a sentinel
        (ss - i)->continuationCorrectionHistory = &this->continuationCorrectionHistory[NO_PIECE][0];
        (ss - i)->staticEval                    = VALUE_NONE;
    }

    for (int i = 0; i <= MAX_PLY + 2; ++i)
        (ss + i)->ply = i;

    ss->pv = pv;

    if (mainThread)
    {
        if (mainThread->bestPreviousScore == VALUE_INFINITE)
            mainThread->iterValue.fill(VALUE_ZERO);
        else
            mainThread->iterValue.fill(mainThread->bestPreviousScore);
    }

    size_t multiPV = size_t(options["MultiPV"]);

    multiPV = std::min(multiPV, rootMoves.size());

    int searchAgainCounter = 0;

    lowPlyHistory.fill(102);

    // Iterative deepening loop until requested to stop or the target depth is reached
    while (++rootDepth < MAX_PLY && !threads.stop
           && !(limits.depth && mainThread && rootDepth > limits.depth))
    {
        // Age out PV variability metric
        if (mainThread)
            totBestMoveChanges /= 2;

        // Save the last iteration's scores before the first PV line is searched and
        // all the move scores except the (new) PV are set to -VALUE_INFINITE.
        for (RootMove& rm : rootMoves)
            rm.previousScore = rm.score;

        size_t pvFirst = 0;
        pvLast         = rootMoves.size();

        if (!threads.increaseDepth)
            searchAgainCounter++;

        // MultiPV loop. We perform a full root search for each PV line
        for (pvIdx = 0; pvIdx < multiPV; ++pvIdx)
        {
            // Reset UCI info selDepth for each depth and each PV line
            selDepth = 0;

            // Reset aspiration window starting size
            delta     = 10 + std::abs(rootMoves[pvIdx].meanSquaredScore) / 41924;
            Value avg = rootMoves[pvIdx].averageScore;
            alpha     = std::max(avg - delta, -VALUE_INFINITE);
            beta      = std::min(avg + delta, VALUE_INFINITE);

            // Adjust optimism based on root move's averageScore
            optimism[us]  = 74 * avg / (std::abs(avg) + 79);
            optimism[~us] = -optimism[us];

            // Start with a small aspiration window and, in the case of a fail
            // high/low, re-search with a bigger window until we don't fail
            // high/low anymore.
            int failedHighCnt = 0;
            while (true)
            {
                // Adjust the effective depth searched, but ensure at least one
                // effective increment for every four searchAgain steps (see issue #2717).
                Depth adjustedDepth =
                  std::max(1, rootDepth - failedHighCnt - 3 * (searchAgainCounter + 1) / 3);
                rootDelta = beta - alpha;
                if (__builtin_expect(revealSearchTuning, false))
                    bestValue = search<Root, true>(rootPos, ss, alpha, beta, adjustedDepth, false);
                else
                    bestValue = search<Root, false>(rootPos, ss, alpha, beta, adjustedDepth, false);

                // Bring the best move to the front. It is critical that sorting
                // is done with a stable algorithm because all the values but the
                // first and eventually the new best one is set to -VALUE_INFINITE
                // and we want to keep the same order for all the moves except the
                // new PV that goes to the front. Note that in the case of MultiPV
                // search the already searched PV lines are preserved.
                std::stable_sort(rootMoves.begin() + pvIdx, rootMoves.begin() + pvLast);

                // If search has been stopped, we break immediately. Sorting is
                // safe because RootMoves is still valid, although it refers to
                // the previous iteration.
                if (threads.stop)
                    break;

                // When failing high/low give some update before a re-search. To avoid
                // excessive output that could hang GUIs, only start at nodes > 10M
                // (rather than depth N, which can be reached quickly)
                if (mainThread && multiPV == 1 && (bestValue <= alpha || bestValue >= beta)
                    && nodes > 10000000)
                    main_manager()->pv(*this, threads, tt, rootDepth);

                // In case of failing low/high increase aspiration window and re-search,
                // otherwise exit the loop.
                if (bestValue <= alpha)
                {
                    beta  = (alpha + beta) / 2;
                    alpha = std::max(bestValue - delta, -VALUE_INFINITE);

                    failedHighCnt = 0;
                    if (mainThread)
                        mainThread->stopOnPonderhit = false;
                }
                else if (bestValue >= beta)
                {
                    beta = std::min(bestValue + delta, VALUE_INFINITE);
                    ++failedHighCnt;
                }
                else
                    break;

                delta += delta / 3;

                assert(alpha >= -VALUE_INFINITE && beta <= VALUE_INFINITE);
            }

            // Sort the PV lines searched so far and update the GUI
            std::stable_sort(rootMoves.begin() + pvFirst, rootMoves.begin() + pvIdx + 1);

            if (mainThread
                && (threads.stop || pvIdx + 1 == multiPV || nodes > 10000000)
                // A thread that aborted search can have mated-in PV and
                // score that cannot be trusted, i.e. it can be delayed or refuted
                // if we would have had time to fully search other root-moves. Thus
                // we suppress this output and below pick a proven score/PV for this
                // thread (from the previous iteration).
                && !(threads.abortedSearch && is_loss(rootMoves[0].uciScore)))
                main_manager()->pv(*this, threads, tt, rootDepth);

            if (threads.stop)
                break;
        }

        if (!threads.stop)
            completedDepth = rootDepth;

        // We make sure not to pick an unproven mated-in score,
        // in case this thread prematurely stopped search (aborted-search).
        if (threads.abortedSearch && rootMoves[0].score != -VALUE_INFINITE
            && is_loss(rootMoves[0].score))
        {
            // Bring the last best move to the front for best thread selection.
            Utility::move_to_front(rootMoves, [&lastBestPV = std::as_const(lastBestPV)](
                                                const auto& rm) { return rm == lastBestPV[0]; });
            rootMoves[0].pv    = lastBestPV;
            rootMoves[0].score = rootMoves[0].uciScore = lastBestScore;
        }
        else if (rootMoves[0].pv[0] != lastBestPV[0])
        {
            lastBestPV        = rootMoves[0].pv;
            lastBestScore     = rootMoves[0].score;
            lastBestMoveDepth = rootDepth;
        }

        if (!mainThread)
            continue;

        // Have we found a "mate in x"?
        if (limits.mate && rootMoves[0].score == rootMoves[0].uciScore
            && ((rootMoves[0].score >= VALUE_MATE_IN_MAX_PLY
                 && VALUE_MATE - rootMoves[0].score <= 2 * limits.mate)
                || (rootMoves[0].score != -VALUE_INFINITE
                    && rootMoves[0].score <= VALUE_MATED_IN_MAX_PLY
                    && VALUE_MATE + rootMoves[0].score <= 2 * limits.mate)))
            threads.stop = true;

        // Use part of the gained time from a previous stable move for the current move
        for (auto&& th : threads)
        {
            totBestMoveChanges += th->worker->bestMoveChanges;
            th->worker->bestMoveChanges = 0;
        }

        // Do we have time for the next iteration? Can we stop searching now?
        if (limits.use_time_management() && !threads.stop && !mainThread->stopOnPonderhit)
        {
            uint64_t nodesEffort =
              rootMoves[0].effort * 100000 / std::max(size_t(1), size_t(nodes));

            double fallingEval =
              (16.198 + 2.638 * (mainThread->bestPreviousAverageScore - bestValue)
               + 0.780 * (mainThread->iterValue[iterIdx] - bestValue))
              / 100.0;
            fallingEval = std::clamp(fallingEval, 0.6378, 1.8394);

            // If the bestMove is stable over several iterations, reduce time accordingly
            double k      = 0.516;
            double center = lastBestMoveDepth + 15;
            timeReduction = 0.8 + 0.85 / (1.089 + std::exp(-k * (completedDepth - center)));
            double reduction =
              (2.0380 + mainThread->previousTimeReduction) / (2.5240 * timeReduction);
            double bestMoveInstability = 0.9381 + 1.6401 * totBestMoveChanges / threads.size();

            double totalTime =
              mainThread->tm.optimum() * fallingEval * reduction * bestMoveInstability;

            auto elapsedTime = elapsed();

            if (completedDepth >= 9 && nodesEffort >= 81808 && elapsedTime > totalTime * 0.6519
                && !mainThread->ponder)
                threads.stop = true;

            // Stop the search if we have exceeded the totalTime or maximum
            if (elapsedTime > std::min(totalTime, double(mainThread->tm.maximum())))
            {
                // If we are allowed to ponder do not stop the search now but
                // keep pondering until the GUI sends "ponderhit" or "stop".
                if (mainThread->ponder)
                    mainThread->stopOnPonderhit = true;
                else
                    threads.stop = true;
            }
            else
                threads.increaseDepth = mainThread->ponder || elapsedTime <= totalTime * 0.264;
        }

        mainThread->iterValue[iterIdx] = bestValue;
        iterIdx                        = (iterIdx + 1) & 3;
    }

    if (!mainThread)
        return;

    mainThread->previousTimeReduction = timeReduction;
}


void Search::Worker::do_move(Position& pos, const Move move, StateInfo& st) {
    do_move(pos, move, st, pos.gives_check(move));
}

void Search::Worker::do_move(Position& pos, const Move move, StateInfo& st, const bool givesCheck) {
    const DirtyPiece dp = pos.do_move(move, st, givesCheck, &tt);
    accumulatorStack.push(dp, pos);
    nodes.fetch_add(1, std::memory_order_relaxed);
}

void Search::Worker::do_null_move(Position& pos, StateInfo& st) { pos.do_null_move(st, tt); }

void Search::Worker::undo_move(Position& pos, const Move move) {
    pos.undo_move(move);
    accumulatorStack.pop();
}

void Search::Worker::undo_null_move(Position& pos) { pos.undo_null_move(); }


// Reset histories, usually before a new game
void Search::Worker::clear() {
    mainHistory.fill(51);
    captureHistory.fill(-560);
    pawnHistory.fill(-1083);
    reset_correction_histories();

    ttMoveHistory = 0;

    for (bool inCheck : {false, true})
        for (StatsType c : {NoCaptures, Captures})
            for (auto& to : continuationHistory[inCheck][c])
                for (auto& h : to)
                    h.fill(-548);

    for (size_t i = 1; i < reductions.size(); ++i)
        reductions[i] = int(2321 / (849 / 10.0) * std::log(i));

#if defined(ABJNNUE_RUNTIME_REFRESH_CACHE)
    refreshTable.clear(networks[numaAccessToken]);
#endif
}

void Search::Worker::reset_correction_histories() {
    pawnCorrectionHistory.fill(6);
    minorPieceCorrectionHistory.fill(0);
    nonPawnCorrectionHistory.fill(0);

    for (auto& to : continuationCorrectionHistory)
        for (auto& h : to)
            h.fill(7);
}


// Main search function for both PV and non-PV nodes
template<NodeType nodeType, bool UseReveal>
Value Search::Worker::search(
  Position& pos, Stack* ss, Value alpha, Value beta, Depth depth, bool cutNode) {

    constexpr bool PvNode   = nodeType != NonPV;
    constexpr bool rootNode = nodeType == Root;
    const bool     allNode  = !(PvNode || cutNode);

    // Dive into quiescence search when the depth reaches zero
    if (depth <= 0)
    {
        constexpr auto nt = PvNode ? PV : NonPV;
        return qsearch<nt, UseReveal>(pos, ss, alpha, beta);
    }

    // Dive into flip search when the last move is moving a dark pieces
    if ((ss - 1)->currentMove.is_ok() && pos.is_dark((ss - 1)->currentMove.to_sq()))
    {
        constexpr auto nt = PvNode ? PV : NonPV;
        return flip_search<nt, UseReveal>(pos, ss, alpha, beta, false, depth, cutNode);
    }

    // Limit the depth if extensions made it too large
    depth = std::min(depth, MAX_PLY - 1);

    assert(-VALUE_INFINITE <= alpha && alpha < beta && beta <= VALUE_INFINITE);
    assert(PvNode || (alpha == beta - 1));
    assert(0 < depth && depth < MAX_PLY);
    assert(!(PvNode && cutNode));

    Move      pv[MAX_PLY + 1];
    StateInfo st;

    Key   posKey;
    Move  move, excludedMove, bestMove;
    Depth extension, newDepth;
    Value bestValue, value, eval, maxValue, probCutBeta;
    bool  givesCheck, improving, priorCapture, opponentWorsening;
    bool  capture, ttCapture, revealMove;
    int   priorReduction;
    Piece movedPiece;

    SearchedList capturesSearched;
    SearchedList quietsSearched;

    // Step 1. Initialize node
    Worker* thisThread = this;
    ss->inCheck        = bool(pos.checkers());
    priorCapture       = pos.captured_piece();
    Color us           = pos.side_to_move();
    ss->moveCount      = 0;
    bestValue          = -VALUE_INFINITE;
    maxValue           = VALUE_INFINITE;

    // Check for the available remaining time
    if (is_mainthread())
        main_manager()->check_time(*thisThread);

    // Used to send selDepth info to GUI (selDepth counts from 1, ply from 0)
    if (PvNode && thisThread->selDepth < ss->ply + 1)
        thisThread->selDepth = ss->ply + 1;

    if (!rootNode)
    {
        // Step 2. Check for aborted search and repetition
        Value result = VALUE_NONE;
        if (pos.rule_judge(result, ss->ply, searchRule))
            return result == VALUE_DRAW ? value_draw(thisThread->nodes) : result;
        if (result != VALUE_NONE)
        {
            assert(result != VALUE_DRAW);

            // 2 fold result is mate for us, the only chance for the opponent is to get a draw
            // We can guarantee to get at least a draw score during searching for that line
            if (result > VALUE_DRAW)
                alpha = std::max(alpha, VALUE_DRAW - 1);
            // 2 fold result is mated for us, the only chance for us is to get a draw
            // We can guarantee to get no more than a draw score during searching for that line
            else
                beta = std::min(beta, VALUE_DRAW + 1);
        }

        if (threads.stop.load(std::memory_order_relaxed) || ss->ply >= MAX_PLY)
            return (ss->ply >= MAX_PLY && !ss->inCheck) ? evaluate(pos)
                                                        : value_draw(thisThread->nodes);

        // Step 3. Mate distance pruning. Even if we mate at the next move our score
        // would be at best mate_in(ss->ply + 1), but if alpha is already bigger because
        // a shorter mate was found upward in the tree then there is no need to search
        // because we will never beat the current alpha. Same logic but with reversed
        // signs apply also in the opposite condition of being mated instead of giving
        // mate. In this case, return a fail-high score.
        alpha = std::max(mated_in(ss->ply), alpha);
        beta  = std::min(mate_in(ss->ply + 1), beta);
        if (alpha >= beta)
            return alpha;
    }
    assert(0 <= ss->ply && ss->ply < MAX_PLY);

    Square prevSq  = ((ss - 1)->currentMove).is_ok() ? ((ss - 1)->currentMove).to_sq() : SQ_NONE;
    bestMove       = Move::none();
    priorReduction = (ss - 1)->reduction;
    (ss - 1)->reduction = 0;
    ss->statScore       = 0;
    ss->isPvNode        = PvNode;
    (ss + 2)->cutoffCnt = 0;

    // Step 4. Transposition table lookup
    excludedMove                   = ss->excludedMove;
    posKey                         = observer_tt_key(pos.key(), rootObserver);
    auto [ttHit, ttData, ttWriter] = tt.probe(posKey);
    // Need further processing of the saved data
    ss->ttHit    = ttHit;
    ttData.move  = rootNode ? thisThread->rootMoves[thisThread->pvIdx].pv[0]
                 : ttHit    ? ttData.move
                            : Move::none();
    ttData.value = ttHit ? value_from_tt(ttData.value, ss->ply, pos.rule40_count()) : VALUE_NONE;
    ss->ttPv     = excludedMove ? ss->ttPv : PvNode || (ttHit && ttData.is_pv);
    ttCapture    = ttData.move && pos.capture(ttData.move);
    const bool canUseTTPruning =
      !useSkyrule || std::min(pos.rule40_count(), pos.state()->pliesFromNull) < 8;

    // At this point, if excluded, skip straight to step 5, static eval. However,
    // to save indentation, we list the condition in all code between here and there.

    // At non-PV nodes we check for an early TT cutoff
    if (canUseTTPruning && !PvNode && !excludedMove && ttData.depth > depth - (ttData.value <= beta)
        && is_valid(ttData.value)  // Can happen when !ttHit or when access race in probe()
        && (ttData.bound & (ttData.value >= beta ? BOUND_LOWER : BOUND_UPPER))
        && (cutNode == (ttData.value >= beta) || depth > 5))
    {
        // If ttMove is quiet, update move sorting heuristics on TT hit
        if (ttData.move && ttData.value >= beta)
        {
            // Bonus for a quiet ttMove that fails high
            if (!ttCapture)
                update_quiet_histories(pos, ss, *this, ttData.move,
                                       std::min(98 * depth - 58, 1488));

            // Extra penalty for early quiet moves of the previous ply
            if (prevSq != SQ_NONE && (ss - 1)->moveCount <= 2 && !priorCapture)
                update_continuation_histories(ss - 1, pos.piece_on(prevSq), prevSq, -2387);
        }

        // Partial workaround for the graph history interaction problem
        // For high rule40 counts don't produce transposition table cutoffs.
        if (pos.rule40_count() < 70)
        {
            if (!useSkyrule && depth >= 8 && ttData.move && pos.pseudo_legal(ttData.move)
                && pos.legal(ttData.move) && !is_decisive(ttData.value)
                && !pos.move_dark(ttData.move))
            {
                do_move(pos, ttData.move, st);
                Key nextPosKey = observer_tt_key(pos.key(), rootObserver);
                auto [ttHitNext, ttDataNext, ttWriterNext] = tt.probe(nextPosKey);
                undo_move(pos, ttData.move);

                // Check that the ttValue after the tt move would also trigger a cutoff
                if (!is_valid(ttDataNext.value))
                    return ttData.value;
                if ((ttData.value >= beta) == (-ttDataNext.value >= beta))
                    return ttData.value;
            }
            else
                return ttData.value;
        }
    }
    else if (canUseTTPruning && !PvNode && !excludedMove
             && ttData.depth > depth - (ttData.value <= beta) && is_valid(ttData.value)
             && ttData.bound != BOUND_EXACT
             && (ttData.bound & (ttData.value >= beta ? BOUND_UPPER : BOUND_LOWER)) && depth > 5)
        ttWriter.penalize(1);

    // Step 5. Static evaluation of the position
    Value      unadjustedStaticEval = VALUE_NONE;
    const auto correctionValue      = correction_value(*thisThread, pos, ss);
    if (ss->inCheck)
    {
        // Skip early pruning when in check
        ss->staticEval = eval = (ss - 2)->staticEval;
        improving             = false;
        goto moves_loop;
    }
    else if (excludedMove)
    {
        eval                 = ss->staticEval;
        unadjustedStaticEval = ttData.eval;
    }
    else if (ss->ttHit)
    {
        // Never assume anything about values stored in TT
        unadjustedStaticEval = ttData.eval;
        if (!is_valid(unadjustedStaticEval))
            unadjustedStaticEval = evaluate(pos);

        ss->staticEval = eval = to_corrected_static_eval(unadjustedStaticEval, correctionValue);

        // ttValue can be used as a better position evaluation
        if (canUseTTPruning && is_valid(ttData.value)
            && (ttData.bound & (ttData.value > eval ? BOUND_LOWER : BOUND_UPPER)))
            eval = ttData.value;
    }
    else
    {
        unadjustedStaticEval = evaluate(pos);
        ss->staticEval = eval = to_corrected_static_eval(unadjustedStaticEval, correctionValue);

        // Static evaluation is saved as it was before adjustment by correction history
        ttWriter.write(posKey, VALUE_NONE, ss->ttPv, BOUND_NONE, DEPTH_UNSEARCHED, Move::none(),
                       unadjustedStaticEval, tt.generation());
    }

    // Use static evaluation difference to improve quiet move ordering
    if (((ss - 1)->currentMove).is_ok() && !(ss - 1)->inCheck && !priorCapture && !ttHit
        && prevSq != SQ_NONE && !pos.is_dark(prevSq))
    {
        int bonus = std::clamp(-19 * int((ss - 1)->staticEval + ss->staticEval), -1271, 1725) + 379;
        thisThread->mainHistory[~us][((ss - 1)->currentMove).from_to()] << bonus * 1269 / 1024;
        if (type_of(pos.piece_on(prevSq)) != PAWN)
            thisThread->pawnHistory[pawn_structure_index(pos)][pos.piece_on(prevSq)][prevSq]
              << bonus * 1267 / 1024;
    }

    // Set up the improving flag, which is true if current static evaluation is
    // bigger than the previous static evaluation at our turn (if we were in
    // check at our previous move we go back until we weren't in check) and is
    // false otherwise. The improving flag is used in various pruning heuristics.
    improving = ss->staticEval > (ss - 2)->staticEval;

    opponentWorsening = ss->staticEval > -(ss - 1)->staticEval;

    if (priorReduction >= 3 && !opponentWorsening)
        depth++;
    if (priorReduction >= 1 && depth >= 2 && ss->staticEval + (ss - 1)->staticEval > 181)
        depth--;

    // Step 6. Razoring
    // If eval is really low, skip search entirely and return the qsearch value.
    // For PvNodes, we must have a guard against mates being returned.
    if (!PvNode && eval < alpha - 1130 - 252 * depth * depth)
        return qsearch<NonPV, UseReveal>(pos, ss, alpha, beta);

    // Step 7. Futility pruning: child node
    // The depth condition is important for mate finding.
    {
        auto futility_margin = [&](Depth d) {
            Value futilityMult = 101 - 37 * (cutNode && !ss->ttHit);

            return futilityMult * d                      //
                 - improving * futilityMult * 2          //
                 - opponentWorsening * futilityMult / 3  //
                 + (ss - 1)->statScore / 132             //
                 + std::abs(correctionValue) / 115091;
        };

        if (!ss->ttPv && depth < 13 && eval - futility_margin(depth) >= beta && eval >= beta
            && (!ttData.move || ttCapture) && !is_loss(beta) && !is_win(eval))
            return beta + (eval - beta) / 3;
    }

    // Step 8. Null move search with verification search
    if (cutNode && (ss - 1)->currentMove != Move::null() && eval >= beta
        && ss->staticEval >= beta - 9 * depth + 201 && !excludedMove && pos.major_material(us)
        && ss->ply >= thisThread->nmpMinPly && !is_loss(beta))
    {
        assert(eval - beta >= 0);

        // Null move dynamic reduction based on depth
        Depth R = 7 + depth / 3;

        ss->currentMove                   = Move::null();
        ss->capturedDark                  = false;
        ss->continuationHistory           = &thisThread->continuationHistory[0][0][NO_PIECE][0];
        ss->continuationCorrectionHistory = &thisThread->continuationCorrectionHistory[NO_PIECE][0];

        do_null_move(pos, st);

        Value nullValue =
          -search<NonPV, UseReveal>(pos, ss + 1, -beta, -beta + 1, depth - R, false);

        undo_null_move(pos);

        // Do not return unproven mate
        if (nullValue >= beta && !is_win(nullValue))
        {
            if (thisThread->nmpMinPly || depth < 16)
                return nullValue;

            assert(!thisThread->nmpMinPly);  // Recursive verification is not allowed

            // Do verification search at high depths, with null move pruning disabled
            // until ply exceeds nmpMinPly.
            thisThread->nmpMinPly = ss->ply + 3 * (depth - R) / 4;

            Value v = search<NonPV, UseReveal>(pos, ss, beta - 1, beta, depth - R, false);

            thisThread->nmpMinPly = 0;

            if (v >= beta)
                return nullValue;
        }
    }

    improving |= ss->staticEval >= beta + 108;

    // Step 9. Internal iterative reductions
    // For PV nodes without a ttMove as well as for deep enough cutNodes, we decrease depth.
    // (*Scaler) Especially if they make IIR less aggressive.
    if (!allNode && depth >= 5 && !ttData.move)
        depth--;

    // Step 10. ProbCut
    // If we have a good enough capture and a reduced search
    // returns a value much above beta, we can (almost) safely prune the previous move.
    probCutBeta = beta + 259 - 65 * improving;
    if (depth >= 3
        && !is_decisive(beta)
        // If value from transposition table is lower than probCutBeta, don't attempt
        // probCut there
        && !(canUseTTPruning && is_valid(ttData.value) && ttData.value < probCutBeta))
    {
        assert(probCutBeta < VALUE_INFINITE && probCutBeta > beta);

        MovePicker mp(pos, ttData.move, probCutBeta - ss->staticEval,
                      &thisThread->captureHistory);
        while ((move = mp.next_move()) != Move::none())
        {
            assert(move.is_ok());

            if (move == excludedMove || !pos.legal(move))
                continue;

            assert(pos.capture(move));

            movedPiece                = pos.moved_piece(move);
            revealMove                = UseReveal && pos.move_dark(move);
            const int moveRevealBonus = 0;

            const bool probCutCapturedDark = pos.is_dark(move.to_sq());
            ss->capturedDark               = probCutCapturedDark;
            do_move(pos, move, st);

            const ProbCutContext localProbCut =
              probcut_context(probCutBeta, depth, probCutCapturedDark);

            ss->currentMove = move;
            ss->continuationHistory =
              &this->continuationHistory[ss->inCheck][true][movedPiece][move.to_sq()];
            ss->continuationCorrectionHistory =
              &this->continuationCorrectionHistory[movedPiece][move.to_sq()];

            // Perform a preliminary qsearch to verify that the move holds
            value = moveRevealBonus == 0
                    ? -hidden_capture_search<NonPV, UseReveal>(pos, ss + 1,
                                                               -localProbCut.beta,
                                                               1 - localProbCut.beta)
                    : reveal_search<NonPV, UseReveal>(pos, ss + 1, localProbCut.beta - 1,
                                                      localProbCut.beta, moveRevealBonus);

            // If the qsearch held, perform the regular search
            if (value >= localProbCut.beta && localProbCut.depth > 0)
                value = moveRevealBonus == 0
                        ? -hidden_capture_search<NonPV, UseReveal>(
                            pos, ss + 1, -localProbCut.beta, 1 - localProbCut.beta, false,
                            localProbCut.depth, !cutNode)
                        : reveal_search<NonPV, UseReveal>(
                            pos, ss + 1, localProbCut.beta - 1, localProbCut.beta,
                            moveRevealBonus, false, localProbCut.depth, !cutNode);

            undo_move(pos, move);

            if (value >= localProbCut.beta)
            {
                // Save ProbCut data into transposition table
                ttWriter.write(posKey, value_to_tt(value, ss->ply), ss->ttPv, BOUND_LOWER,
                               localProbCut.depth + 1, move, unadjustedStaticEval,
                               tt.generation());

                if (!is_decisive(value))
                    return value - (localProbCut.beta - beta);
            }
        }
    }

moves_loop:  // When in check, search starts here

    // Step 11. A small Probcut idea
    probCutBeta = beta + 430;
    if (canUseTTPruning && (ttData.bound & BOUND_LOWER) && ttData.depth >= depth - 4
        && ttData.value >= probCutBeta && !is_decisive(beta) && is_valid(ttData.value)
        && !is_decisive(ttData.value))
        return probCutBeta;

    const PieceToHistory* contHist[] = {
      (ss - 1)->continuationHistory, (ss - 2)->continuationHistory, (ss - 3)->continuationHistory,
      (ss - 4)->continuationHistory, (ss - 5)->continuationHistory, (ss - 6)->continuationHistory};


    MovePicker mp(pos, ttData.move, depth, &thisThread->mainHistory, &thisThread->lowPlyHistory,
                  &thisThread->captureHistory, contHist, &thisThread->pawnHistory, ss->ply);

    value = bestValue;

    int moveCount = 0;

    // Step 12. Loop through all pseudo-legal moves until no moves remain
    // or a beta cutoff occurs.
    while ((move = mp.next_move()) != Move::none())
    {
        assert(move.is_ok());

        if (move == excludedMove)
            continue;

        // Check for legality
        if (!pos.legal(move))
            continue;

        // At root obey the "searchmoves" option and skip moves not listed in Root Move List.
        // In MultiPV mode we also skip PV moves that have been already searched.
        if (rootNode
            && !std::count(thisThread->rootMoves.begin() + thisThread->pvIdx,
                           thisThread->rootMoves.begin() + thisThread->pvLast, move))
            continue;

        capture    = pos.capture(move);
        revealMove = UseReveal && pos.move_dark(move);
        const Reveal::QuietMoveContext quietContext =
          Reveal::quiet_move_context(pos, move, UseReveal && quietSafetyNeeded);
        assert(!quietContext.eligible || (revealMove && !capture));
        if (useSkyrule && !capture && !pos.move_dark(move) && pos.forbidden_by_skyrule_jieqi(move))
            continue;

        ss->moveCount = ++moveCount;

        if (rootNode && is_mainthread() && nodes > 10000000)
        {
            main_manager()->updates.onIter(
              {depth, UCIEngine::move(move), moveCount + thisThread->pvIdx});
        }
        if (PvNode)
            (ss + 1)->pv = nullptr;

        extension  = 0;
        movedPiece = pos.moved_piece(move);
        givesCheck = pos.gives_check(move);

        (ss + 1)->quietMoveStreak = (!capture && !givesCheck) ? (ss->quietMoveStreak + 1) : 0;

        // Calculate new depth for this move
        newDepth = depth - 1;

        int delta = beta - alpha;

        Depth r = reduction(improving, depth, moveCount, delta);
        // Increase reduction for ttPv nodes (*Scaler)
        // Smaller or even negative value is better for short time controls
        // Bigger value is better for long time controls
        if (ss->ttPv)
            r += 910;

        // Step 13. Pruning at shallow depth.
        // Depth conditions are important for mate finding.
        if (!rootNode && pos.major_material(us) && !is_loss(bestValue))
        {
            // Skip quiet moves if movecount exceeds our FutilityMoveCount threshold
            const int baseMoveCountLimit = (3 + depth * depth) / (2 - improving);
            if (moveCount >= baseMoveCountLimit)
                mp.skip_quiet_moves();

            // Reduced depth of the next LMR search
            int lmrDepth = newDepth - r / 811;

            if (capture || givesCheck)
            {
                Piece capturedPiece = pos.piece_on(move.to_sq());
                int   captHist =
                  thisThread->captureHistory[movedPiece][move.to_sq()][type_of(capturedPiece)];

                // Futility pruning for captures
                if (!givesCheck && lmrDepth < 18 && !ss->inCheck)
                {
                    Value futilityValue = ss->staticEval + 307 + 365 * lmrDepth
                                        + PieceValue[capturedPiece] + 105 * captHist / 491;
                    if (futilityValue <= alpha)
                        continue;
                }

                // SEE based pruning for captures and checks
                int seeHist = std::clamp(captHist / 30, -204 * depth, 186 * depth);
                if (!pos.see_ge(move, -225 * depth - seeHist))
                    continue;
            }
            else
            {
                int history =
                  (*contHist[0])[movedPiece][move.to_sq()]
                  + (*contHist[1])[movedPiece][move.to_sq()]
                  + thisThread->pawnHistory[pawn_structure_index(pos)][movedPiece][move.to_sq()];

                // Continuation history based pruning
                if (history < -3491 * depth)
                    continue;

                history += 60 * thisThread->mainHistory[us][move.from_to()] / 28;

                lmrDepth += history / 3626;

                Value baseFutility  = (bestMove ? 48 : 275);
                Value futilityValue = ss->staticEval + baseFutility + 126 * lmrDepth
                                    + 103 * (ss->staticEval > alpha);

                // Futility pruning: parent node
                // (*Scaler): Generally, more frequent futility pruning
                // scales well with respect to time and threads
                if (!ss->inCheck && lmrDepth < 8 && futilityValue <= alpha)
                {
                    if (bestValue <= futilityValue && !is_decisive(bestValue)
                        && !is_win(futilityValue))
                        bestValue = futilityValue;
                    continue;
                }

                lmrDepth = std::max(lmrDepth, 0);

                // Prune moves with negative SEE
                if (!pos.see_ge(move, -38 * lmrDepth * lmrDepth))
                    continue;
            }
        }

        // Step 14. Extensions
        // Singular extension search. If all moves but one
        // fail low on a search of (alpha-s, beta-s), and just one fails high on
        // (alpha, beta), then that move is singular and should be extended. To
        // verify this we do a reduced search on the position excluding the ttMove
        // and if the result is lower than ttValue minus a margin, then we will
        // extend the ttMove. Recursive singular search is avoided.

        // (*Scaler) Generally, higher singularBeta (i.e closer to ttValue)
        // and lower extension margins scale well.

        if (canUseTTPruning && !rootNode && move == ttData.move && !excludedMove
            && depth >= 5 - (thisThread->completedDepth > 32) + ss->ttPv && is_valid(ttData.value)
            && !is_decisive(ttData.value) && (ttData.bound & BOUND_LOWER)
            && ttData.depth >= depth - 3)
        {
            Value singularBeta  = ttData.value - (48 + 72 * (ss->ttPv && !PvNode)) * depth / 59;
            Depth singularDepth = newDepth / 2;

            ss->excludedMove = move;
            value = search<NonPV, UseReveal>(pos, ss, singularBeta - 1, singularBeta, singularDepth,
                                             cutNode);
            ss->excludedMove = Move::none();

            if (value < singularBeta)
            {
                int corrValAdj   = std::abs(correctionValue) / 285633;
                int doubleMargin = -4 + 252 * PvNode - 152 * !ttCapture - corrValAdj
                                 - 1091 * ttMoveHistory / 144928
                                 - (ss->ply > thisThread->rootDepth) * 49;
                int tripleMargin = 85 + 303 * PvNode - 228 * !ttCapture + 88 * ss->ttPv - corrValAdj
                                 - (ss->ply * 2 > thisThread->rootDepth * 3) * 61;

                extension =
                  1 + (value < singularBeta - doubleMargin) + (value < singularBeta - tripleMargin);

                depth++;
            }

            // Multi-cut pruning
            // Our ttMove is assumed to fail high based on the bound of the TT entry,
            // and if after excluding the ttMove with a reduced search we fail high
            // over the original beta, we assume this expected cut-node is not
            // singular (multiple moves fail high), and we can prune the whole
            // subtree by returning a softbound.
            else if (value >= beta && !is_decisive(value))
                return value;

            // Negative extensions
            // If other moves failed high over (ttValue - margin) without the
            // ttMove on a reduced search, but we cannot do multi-cut because
            // (ttValue - margin) is lower than the original beta, we do not know
            // if the ttMove is singular or can do a multi-cut, so we reduce the
            // ttMove in favor of other moves based on some conditions:

            // If the ttMove is assumed to fail high over current beta
            else if (ttData.value >= beta)
                extension = -3;

            // If we are on a cutNode but the ttMove is not assumed to fail high
            // over current beta
            else if (cutNode)
                extension = -2;
        }

        // Step 15. Make the move
        const int moveRevealBonus =
          revealMove ? reveal_bonus(pos, quietContext) : 0;
        ss->capturedDark          = capture && pos.is_dark(move.to_sq());
        do_move(pos, move, st, givesCheck);

        // Add extension to new depth
        newDepth += extension;

        // Update the current move (this must be done after singular extension search)
        ss->currentMove = move;
        ss->continuationHistory =
          &thisThread->continuationHistory[ss->inCheck][capture][movedPiece][move.to_sq()];
        ss->continuationCorrectionHistory =
          &thisThread->continuationCorrectionHistory[movedPiece][move.to_sq()];
        uint64_t nodeCount = rootNode ? uint64_t(nodes) : 0;

        // Decrease reduction for PvNodes (*Scaler)
        if (ss->ttPv)
            r -= 2082 + PvNode * 1139 + (ttData.value > alpha) * 915
               + (ttData.depth >= depth) * (1037 + cutNode * 1023);

        // These reduction adjustments have no proven non-linear scaling

        r += 328;  // Base reduction offset to compensate for other tweaks
        r -= moveCount * 61;
        r -= std::abs(correctionValue) / 32919;

        // Increase reduction for cut nodes
        if (cutNode)
            r += 3065 + 998 * !ttData.move;

        // Increase reduction if ttMove is a capture
        if (ttCapture)
            r += 1333 + (depth < 8) * 1130;

        // Increase reduction if next ply has a lot of fail high
        if ((ss + 1)->cutoffCnt > 2)
            r += 1449 + allNode * 968;

        r += (ss + 1)->quietMoveStreak * 49;

        // For first picked move (ttMove) reduce reduction
        if (move == ttData.move)
            r -= 2753;

        if (capture)
            ss->statScore =
              786 * int(PieceValue[pos.captured_piece()]) / 100
              + thisThread->captureHistory[movedPiece][move.to_sq()][type_of(pos.captured_piece())]
              - 4998;
        else
            ss->statScore = 2 * thisThread->mainHistory[us][move.from_to()]
                          + (*contHist[0])[movedPiece][move.to_sq()]
                          + (*contHist[1])[movedPiece][move.to_sq()] - 3804;

        // Decrease/increase reduction for moves with a good/bad history
        r -= ss->statScore * 955 / 9646;

        // Step 16. Late moves reduction / extension (LMR)
        if (depth >= 2 && moveCount > 1)
        {
            // In general we want to cap the LMR depth search at newDepth, but when
            // reduction is negative, we allow this move a limited search extension
            // beyond the first move depth.
            // To prevent problems when the max value is less than the min value,
            // std::clamp has been replaced by a more robust implementation.
            Depth d = std::max(1, std::min(newDepth - r / 1090,
                                           newDepth + !allNode + (PvNode && !bestMove)))
                    + (ss - 1)->isPvNode;

            ss->reduction = newDepth - d;
            value = moveRevealBonus == 0
                    ? -hidden_capture_search<NonPV, UseReveal>(pos, ss + 1, -alpha - 1, -alpha,
                                                               false, d, true)
                    : reveal_search<NonPV, UseReveal>(pos, ss + 1, alpha, alpha + 1,
                                                      moveRevealBonus, false, d, true);
            ss->reduction = 0;

            // Do a full-depth search when reduced LMR search fails high
            // (*Scaler) Usually doing more shallower searches
            // doesn't scale well to longer TCs
            if (value > alpha && d < newDepth)
            {
                // Adjust full-depth search based on LMR results - if the result was
                // good enough search deeper, if it was bad enough search shallower.
                const bool doDeeperSearch    = value > (bestValue + 52 + 2 * newDepth);
                const bool doShallowerSearch = value < bestValue + 9;

                newDepth += doDeeperSearch - doShallowerSearch;

                if (newDepth > d)
                    value = moveRevealBonus == 0
                            ? -hidden_capture_search<NonPV, UseReveal>(
                                pos, ss + 1, -alpha - 1, -alpha, false, newDepth, !cutNode)
                            : reveal_search<NonPV, UseReveal>(pos, ss + 1, alpha, alpha + 1,
                                                              moveRevealBonus, false, newDepth,
                                                              !cutNode);

                // Post LMR continuation history updates
                update_continuation_histories(ss, movedPiece, move.to_sq(), 1533);
            }
            else if (value > alpha && value < bestValue + 9)
                newDepth--;
        }

        // Step 17. Full-depth search when LMR is skipped
        else if (!PvNode || moveCount > 1)
        {
            // Increase reduction if ttMove is not present
            if (!ttData.move)
                r += 875;

            r -= ttMoveHistory / 8;

            // Note that if expected reduction is high, we reduce search depth here
            value =
              moveRevealBonus == 0
                ? -hidden_capture_search<NonPV, UseReveal>(
                    pos, ss + 1, -alpha - 1, -alpha, false,
                    newDepth - (r > 4170) - (r > 5563 && newDepth > 2), !cutNode)
                : reveal_search<NonPV, UseReveal>(
                    pos, ss + 1, alpha, alpha + 1, moveRevealBonus, false,
                    newDepth - (r > 4170) - (r > 5563 && newDepth > 2), !cutNode);
        }

        // For PV nodes only, do a full PV search on the first move or after a fail high,
        // otherwise let the parent node fail low with value <= alpha and try another move.
        if (PvNode && (moveCount == 1 || value > alpha))
        {
            (ss + 1)->pv    = pv;
            (ss + 1)->pv[0] = Move::none();

            // Extend move from transposition table if we are about to dive into qsearch.
            if (move == ttData.move && thisThread->rootDepth > 8)
                newDepth = std::max(newDepth, 1);

            value = moveRevealBonus == 0
                    ? -hidden_capture_search<PV, UseReveal>(pos, ss + 1, -beta, -alpha, false,
                                                            newDepth, false)
                    : reveal_search<PV, UseReveal>(pos, ss + 1, alpha, beta, moveRevealBonus, false,
                                                   newDepth, false);
        }

        // Step 18. Undo move
        undo_move(pos, move);

        assert(value > -VALUE_INFINITE && value < VALUE_INFINITE);

        // Step 19. Check for a new best move
        // Finished searching the move. If a stop occurred, the return value of
        // the search cannot be trusted, and we return immediately without updating
        // best move, principal variation nor transposition table.
        if (threads.stop.load(std::memory_order_relaxed))
            return VALUE_ZERO;

        if (rootNode)
        {
            RootMove& rm =
              *std::find(thisThread->rootMoves.begin(), thisThread->rootMoves.end(), move);

            rm.effort += nodes - nodeCount;

            rm.averageScore =
              rm.averageScore != -VALUE_INFINITE ? (value + rm.averageScore) / 2 : value;

            rm.meanSquaredScore = rm.meanSquaredScore != -VALUE_INFINITE * VALUE_INFINITE
                                  ? (value * std::abs(value) + rm.meanSquaredScore) / 2
                                  : value * std::abs(value);

            // PV move or new best move?
            if (moveCount == 1 || value > alpha)
            {
                rm.score = rm.uciScore = value;
                rm.selDepth            = thisThread->selDepth;
                rm.scoreLowerbound = rm.scoreUpperbound = false;

                if (value >= beta)
                {
                    rm.scoreLowerbound = true;
                    rm.uciScore        = beta;
                }
                else if (value <= alpha)
                {
                    rm.scoreUpperbound = true;
                    rm.uciScore        = alpha;
                }

                rm.pv.resize(1);

                assert((ss + 1)->pv);

                for (Move* m = (ss + 1)->pv; *m != Move::none(); ++m)
                    rm.pv.push_back(*m);

                // We record how often the best move has been changed in each iteration.
                // This information is used for time management. In MultiPV mode,
                // we must take care to only do this for the first PV line.
                if (moveCount > 1 && !thisThread->pvIdx)
                    ++thisThread->bestMoveChanges;
            }
            else
                // All other moves but the PV, are set to the lowest value: this
                // is not a problem when sorting because the sort is stable and the
                // move position in the list is preserved - just the PV is pushed up.
                rm.score = -VALUE_INFINITE;
        }

        // In case we have an alternative move equal in eval to the current bestmove,
        // promote it to bestmove by pretending it just exceeds alpha (but not beta).
        int inc = (value == bestValue && ss->ply + 2 >= thisThread->rootDepth
                   && (int(nodes) & 15) == 0 && !is_win(std::abs(value) + 1));

        if (value + inc > bestValue)
        {
            bestValue = value;

            if (value + inc > alpha)
            {
                bestMove = move;

                if (PvNode && !rootNode)  // Update pv even in fail-high case
                    update_pv(ss->pv, move, (ss + 1)->pv);

                if (value >= beta)
                {
                    // (* Scaler) Especially if they make cutoffCnt increment more often.
                    ss->cutoffCnt += (extension < 2) || PvNode;
                    assert(value >= beta);  // Fail high
                    break;
                }

                // Reduce other moves if we have found at least one score improvement
                if (depth > 2 && depth < 11 && !is_decisive(value))
                    depth -= 2;

                assert(depth > 0);
                alpha = value;  // Update alpha! Always alpha < beta
            }
        }

        // If the move is worse than some previously searched move,
        // remember it, to update its stats later.
        if (move != bestMove && moveCount <= SEARCHEDLIST_CAPACITY)
        {
            if (capture)
                capturesSearched.push_back(move);
            else
                quietsSearched.push_back(move);
        }
    }

    // Step 20. Check for mate
    // All legal moves have been searched and if there are no legal moves,
    // it must be a mate. If we are in a singular extension search then
    // return a fail low score.

    assert(moveCount || !ss->inCheck || excludedMove || !MoveList<LEGAL>(pos).size());

    // Adjust best value for fail high cases
    if (bestValue >= beta && !is_decisive(bestValue) && !is_decisive(alpha))
        bestValue = (bestValue * depth + beta) / (depth + 1);

    if (!moveCount)
        bestValue = excludedMove ? alpha : mated_in(ss->ply);

    // If there is a move that produces search value greater than alpha,
    // we update the stats of searched moves.
    else if (bestMove)
    {
        update_all_stats(pos, ss, *this, bestMove, prevSq, quietsSearched, capturesSearched, depth,
                         ttData.move, moveCount);
        if (!PvNode)
            ttMoveHistory << (bestMove == ttData.move ? 774 : -844);
    }

    // Bonus for prior quiet countermove that caused the fail low
    else if (!priorCapture && prevSq != SQ_NONE)
    {
        int bonusScale = -251;
        bonusScale += std::min(-(ss - 1)->statScore / 76, 256);
        bonusScale += std::min(54 * depth, 549);
        bonusScale += 138 * ((ss - 1)->moveCount > 12);
        bonusScale += 70 * (!ss->inCheck && bestValue <= ss->staticEval - 184);
        bonusScale += 154 * (!(ss - 1)->inCheck && bestValue <= -(ss - 1)->staticEval - 132);

        bonusScale = std::max(bonusScale, 0);

        const int scaledBonus = std::min(153 * depth - 93, 2290) * bonusScale;

        update_continuation_histories(ss - 1, pos.piece_on(prevSq), prevSq,
                                      scaledBonus * 384 / 32768);

        thisThread->mainHistory[~us][((ss - 1)->currentMove).from_to()]
          << scaledBonus * 221 / 32768;

        if (type_of(pos.piece_on(prevSq)) != PAWN)
            thisThread->pawnHistory[pawn_structure_index(pos)][pos.piece_on(prevSq)][prevSq]
              << scaledBonus * 1001 / 32768;
    }

    // Bonus for prior capture countermove that caused the fail low
    else if (priorCapture && prevSq != SQ_NONE)
    {
        Piece capturedPiece = pos.captured_piece();
        assert(capturedPiece != NO_PIECE);
        thisThread->captureHistory[pos.piece_on(prevSq)][prevSq][type_of(capturedPiece)] << 958;
    }

    if (PvNode)
        bestValue = std::min(bestValue, maxValue);

    // If no good move is found and the previous position was ttPv, then the previous
    // opponent move is probably good and the new position is added to the search tree.
    if (bestValue <= alpha)
        ss->ttPv = ss->ttPv || (ss - 1)->ttPv;

    // Write gathered information in transposition table. Note that the
    // static evaluation is saved as it was before correction history.
    if (!excludedMove && !(rootNode && thisThread->pvIdx))
        ttWriter.write(posKey, value_to_tt(bestValue, ss->ply), ss->ttPv,
                       bestValue >= beta    ? BOUND_LOWER
                       : PvNode && bestMove ? BOUND_EXACT
                                            : BOUND_UPPER,
                       moveCount != 0 ? depth : std::min(MAX_PLY - 1, depth + 6), bestMove,
                       unadjustedStaticEval, tt.generation());

    // Adjust correction history
    if (!ss->inCheck && !(bestMove && pos.capture(bestMove))
        && ((bestValue < ss->staticEval && bestValue < beta)  // negative correction & no fail high
            || (bestValue > ss->staticEval && bestMove)))     // positive correction & no fail low
    {
        auto bonus = std::clamp(int(bestValue - ss->staticEval) * depth / 8,
                                -CORRECTION_HISTORY_LIMIT / 4, CORRECTION_HISTORY_LIMIT / 4);
        update_correction_history(pos, ss, *thisThread, bonus);
    }

    assert(bestValue > -VALUE_INFINITE && bestValue < VALUE_INFINITE);

    return bestValue;
}


// Quiescence search function, which is called by the main search function with
// depth zero, or recursively with further decreasing depth. With depth <= 0, we
// "should" be using static eval only, but tactical moves may confuse the static eval.
// To fight this horizon effect, we implement this qsearch of tactical moves.
// See https://www.chessprogramming.org/Horizon_Effect
// and https://www.chessprogramming.org/Quiescence_Search
template<NodeType nodeType, bool UseReveal>
Value Search::Worker::qsearch(Position& pos, Stack* ss, Value alpha, Value beta) {

    static_assert(nodeType != Root);
    constexpr bool PvNode = nodeType == PV;

    // Dive into flip search when the last move is moving a dark pieces
    if ((ss - 1)->currentMove.is_ok() && pos.is_dark((ss - 1)->currentMove.to_sq()))
    {
        constexpr auto nt = PvNode ? PV : NonPV;
        return flip_search<nt, UseReveal>(pos, ss, alpha, beta);
    }

    assert(alpha >= -VALUE_INFINITE && alpha < beta && beta <= VALUE_INFINITE);
    assert(PvNode || (alpha == beta - 1));

    Move      pv[MAX_PLY + 1];
    StateInfo st;

    Key   posKey;
    Move  move, bestMove;
    Value bestValue, value, futilityBase;
    bool  pvHit, givesCheck, capture, revealMove;
    int   moveCount;

    // Step 1. Initialize node
    if (PvNode)
    {
        (ss + 1)->pv = pv;
        ss->pv[0]    = Move::none();
    }

    Worker* thisThread = this;
    bestMove           = Move::none();
    ss->inCheck        = bool(pos.checkers());
    moveCount          = 0;

    // Qsearch can traverse a large tactical subtree without re-entering the
    // normal search function. Check the same movetime watchdog at its entry
    // and abort promptly when the limit has already expired.
    if (is_mainthread())
        main_manager()->check_time(*thisThread);
    if (threads.stop.load(std::memory_order_relaxed))
        return VALUE_ZERO;

    // Used to send selDepth info to GUI (selDepth counts from 1, ply from 0)
    if (PvNode && thisThread->selDepth < ss->ply + 1)
        thisThread->selDepth = ss->ply + 1;

    // Step 2. Check for repetition or maximum ply reached
    Value result = VALUE_NONE;
    if (pos.rule_judge(result, ss->ply, searchRule))
        return result;
    if (result != VALUE_NONE)
    {
        assert(result != VALUE_DRAW);

        // 2 fold result is mate for us, the only chance for the opponent is to get a draw
        // We can guarantee to get at least a draw score during searching for that line
        if (result > VALUE_DRAW)
            alpha = std::max(alpha, VALUE_DRAW);
        // 2 fold result is mated for us, the only chance for us is to get a draw
        // We can guarantee to get no more than a draw score during searching for that line
        else
            beta = std::min(beta, VALUE_DRAW);

        if (alpha >= beta)
            return alpha;
    }

    if (ss->ply >= MAX_PLY)
        return !ss->inCheck ? evaluate(pos) : VALUE_DRAW;

    assert(0 <= ss->ply && ss->ply < MAX_PLY);

    // Step 3. Transposition table lookup
    posKey                         = observer_tt_key(pos.key(), rootObserver);
    auto [ttHit, ttData, ttWriter] = tt.probe(posKey);
    // Need further processing of the saved data
    ss->ttHit    = ttHit;
    ttData.move  = ttHit ? ttData.move : Move::none();
    ttData.value = ttHit ? value_from_tt(ttData.value, ss->ply, pos.rule40_count()) : VALUE_NONE;
    pvHit        = ttHit && ttData.is_pv;
    const bool canUseTTPruning =
      !useSkyrule || std::min(pos.rule40_count(), pos.state()->pliesFromNull) < 8;

    // At non-PV nodes we check for an early TT cutoff
    if (canUseTTPruning && !PvNode && ttData.depth >= DEPTH_QS
        && is_valid(ttData.value)  // Can happen when !ttHit or when access race in probe()
        && (ttData.bound & (ttData.value >= beta ? BOUND_LOWER : BOUND_UPPER)))
        return ttData.value;

    // Step 4. Static evaluation of the position
    Value unadjustedStaticEval = VALUE_NONE;
    if (ss->inCheck)
        bestValue = futilityBase = -VALUE_INFINITE;
    else
    {
        const auto correctionValue = correction_value(*thisThread, pos, ss);

        if (ss->ttHit)
        {
            // Never assume anything about values stored in TT
            unadjustedStaticEval = ttData.eval;
            if (!is_valid(unadjustedStaticEval))
                unadjustedStaticEval = evaluate(pos);
            ss->staticEval = bestValue =
              to_corrected_static_eval(unadjustedStaticEval, correctionValue);

            // ttValue can be used as a better position evaluation
            if (canUseTTPruning && is_valid(ttData.value) && !is_decisive(ttData.value)
                && (ttData.bound & (ttData.value > bestValue ? BOUND_LOWER : BOUND_UPPER)))
                bestValue = ttData.value;
        }
        else
        {
            unadjustedStaticEval = evaluate(pos);

            ss->staticEval = bestValue =
              to_corrected_static_eval(unadjustedStaticEval, correctionValue);
        }

        // Stand pat. Return immediately if static value is at least beta
        if (bestValue >= beta)
        {
            if (!is_decisive(bestValue))
                bestValue = (bestValue + beta) / 2;
            if (!ss->ttHit)
                ttWriter.write(posKey, value_to_tt(bestValue, ss->ply), false, BOUND_LOWER,
                               DEPTH_UNSEARCHED, Move::none(), unadjustedStaticEval,
                               tt.generation());
            return bestValue;
        }

        if (bestValue > alpha)
            alpha = bestValue;

        futilityBase = ss->staticEval + 159;
    }

    const PieceToHistory* contHist[] = {(ss - 1)->continuationHistory,
                                        (ss - 2)->continuationHistory};

    Square prevSq = ((ss - 1)->currentMove).is_ok() ? ((ss - 1)->currentMove).to_sq() : SQ_NONE;

    // Initialize a MovePicker object for the current position, and prepare to search
    // the moves. We presently use two stages of move generator in quiescence search:
    // captures, or evasions only when in check.
    MovePicker mp(pos, ttData.move, DEPTH_QS, &thisThread->mainHistory,
                  &thisThread->lowPlyHistory, &thisThread->captureHistory, contHist,
                  &thisThread->pawnHistory, ss->ply);

    // Step 5. Loop through all pseudo-legal moves until no moves remain or a beta
    // cutoff occurs.
    while ((move = mp.next_move()) != Move::none())
    {
        if (threads.stop.load(std::memory_order_relaxed))
            return VALUE_ZERO;
        assert(move.is_ok());

        if (!pos.legal(move))
            continue;

        capture    = pos.capture(move);
        revealMove = UseReveal && pos.move_dark(move);
        const Reveal::QuietMoveContext quietContext = Reveal::quiet_move_context(
          pos, move,
          Reveal::qsearch_quiet_context_enabled(UseReveal, ss->inCheck, quietSafetyNeeded));
        assert(!quietContext.eligible || (revealMove && !capture));
        if (useSkyrule && !capture && !pos.move_dark(move) && pos.forbidden_by_skyrule_jieqi(move))
            continue;
        givesCheck = pos.gives_check(move);

        moveCount++;

        // Step 6. Pruning
        if (!is_loss(bestValue))
        {
            // Futility pruning and moveCount pruning
            if (!givesCheck && move.to_sq() != prevSq && !is_loss(futilityBase))
            {
                if (moveCount > 2)
                    continue;

                Value futilityValue = futilityBase + PieceValue[pos.piece_on(move.to_sq())];

                // If static eval + value of piece we are going to capture is
                // much lower than alpha, we can prune this move.
                if (futilityValue <= alpha)
                {
                    bestValue = std::max(bestValue, futilityValue);
                    continue;
                }

                // If static exchange evaluation is low enough
                // we can prune this move.
                if (!pos.see_ge(move, alpha - futilityBase))
                {
                    bestValue = std::min(alpha, futilityBase);
                    continue;
                }
            }

            // Continuation history based pruning
            if (!capture
                && (*contHist[0])[pos.moved_piece(move)][move.to_sq()]
                       + thisThread->pawnHistory[pawn_structure_index(pos)][pos.moved_piece(move)]
                                                [move.to_sq()]
                     <= 2861)
                continue;

            // Do not search moves with bad enough SEE values
            if (!pos.see_ge(move, -114))
                continue;
        }

        // Step 7. Make and search the move
        Piece     movedPiece      = pos.moved_piece(move);
        const int moveRevealBonus =
          revealMove ? reveal_bonus(pos, quietContext) : 0;

        ss->capturedDark = capture && pos.is_dark(move.to_sq());
        do_move(pos, move, st, givesCheck);

        // Update the current move
        ss->currentMove = move;
        ss->continuationHistory =
          &thisThread->continuationHistory[ss->inCheck][capture][movedPiece][move.to_sq()];
        ss->continuationCorrectionHistory =
          &thisThread->continuationCorrectionHistory[movedPiece][move.to_sq()];

        value = moveRevealBonus == 0
                ? -hidden_capture_search<nodeType, UseReveal>(pos, ss + 1, -beta, -alpha)
                : reveal_search<nodeType, UseReveal>(pos, ss + 1, alpha, beta, moveRevealBonus);
        undo_move(pos, move);

        if (threads.stop.load(std::memory_order_relaxed))
            return VALUE_ZERO;

        assert(value > -VALUE_INFINITE && value < VALUE_INFINITE);

        // Step 8. Check for a new best move
        if (value > bestValue)
        {
            bestValue = value;

            if (value > alpha)
            {
                bestMove = move;

                if (PvNode)  // Update pv even in fail-high case
                    update_pv(ss->pv, move, (ss + 1)->pv);

                if (value < beta)  // Update alpha here!
                    alpha = value;
                else
                    break;  // Fail high
            }
        }
    }

    // Step 9. Check for mate
    // All legal moves have been searched. A special case: if no legal
    // moves were found, it is checkmate.
    if (bestValue == -VALUE_INFINITE || (!moveCount && [&] {
            for (const auto& m : MoveList<QUIETS>(pos))
                if (pos.legal(m))
                    return false;
            return true;
        }()))
    {
        assert(!MoveList<LEGAL>(pos).size());
        return mated_in(ss->ply);  // Plies to mate from the root
    }

    if (!is_decisive(bestValue) && bestValue > beta)
        bestValue = (bestValue + beta) / 2;

    // Save gathered info in transposition table. The static evaluation
    // is saved as it was before adjustment by correction history.
    ttWriter.write(posKey, value_to_tt(bestValue, ss->ply), pvHit,
                   bestValue >= beta ? BOUND_LOWER : BOUND_UPPER, DEPTH_QS, bestMove,
                   unadjustedStaticEval, tt.generation());

    assert(bestValue > -VALUE_INFINITE && bestValue < VALUE_INFINITE);

    return bestValue;
}


template<NodeType nodeType, bool UseReveal>
Value Search::Worker::reveal_search(Position& pos,
                                    Stack*    ss,
                                    Value     alpha,
                                    Value     beta,
                                    int       revealBonus,
                                    bool      isQsearch,
                                    Depth     depth,
                                    bool      cutNode) {
    // Keep the untuned/default hot path identical to the original negamax
    // call. Besides avoiding needless inverse-window arithmetic, this matters
    // for time-control strength when all reveal-reward weights are zero.
    if (revealBonus == 0)
        return -hidden_capture_search<nodeType, UseReveal>(pos, ss, -beta, -alpha, isQsearch,
                                                            depth, cutNode);

    return Reveal::search_with_bonus(
      alpha, beta, revealBonus, [&](Value childAlpha, Value childBeta) {
          return hidden_capture_search<nodeType, UseReveal>(pos, ss, childAlpha, childBeta,
                                                             isQsearch, depth, cutNode);
      });
}


template<NodeType nodeType, bool UseReveal>
Value Search::Worker::hidden_capture_search(
  Position& pos, Stack* ss, Value alpha, Value beta, bool isQsearch, Depth depth, bool cutNode) {
    Position::RestPieceList restPieces;
    const int               restPieceCount =
      hidden_capture_candidates(pos, rootObserver, (ss - 1)->capturedDark, restPieces);

    if (restPieceCount == 0)
        return isQsearch ? qsearch<nodeType, UseReveal>(pos, ss, alpha, beta)
                         : search<nodeType, UseReveal>(pos, ss, alpha, beta, depth, cutNode);

    DirtyPiece dp = accumulatorStack.latest_dirty_piece();
    ChanceBranchReduction branchReduction((ss - 1)->reduction);

    if (restPieceCount == 1)
    {
        const Piece piece = restPieces[0].first;
        branchReduction.restore();

        accumulatorStack.pop();
        pos.remove_rest_piece(piece);
        accumulatorStack.push(dp, pos);

        const Value value =
          isQsearch ? qsearch<nodeType, UseReveal>(pos, ss, alpha, beta)
                    : search<nodeType, UseReveal>(pos, ss, alpha, beta, depth, cutNode);

        pos.restore_rest_piece(piece);
        return value;
    }

    int                              total        = 0;
    bool                             allDecisive  = true;
    Value                            bestWinMate  = VALUE_MATE;
    Value                            bestLossMate = -VALUE_MATE;
    std::vector<std::pair<int, int>> probabilitySamples;
    probabilitySamples.reserve(restPieceCount);

    for (int i = 0; i < restPieceCount; ++i)
    {
        const auto [piece, count] = restPieces[i];
        total += count;
        branchReduction.restore();

        accumulatorStack.pop();
        pos.remove_rest_piece(piece);
        accumulatorStack.push(dp, pos);

        const Value value =
          isQsearch ? qsearch<nodeType, UseReveal>(pos, ss, alpha, beta)
                    : search<nodeType, UseReveal>(pos, ss, alpha, beta, depth, cutNode);

        pos.restore_rest_piece(piece);

        if (threads.stop.load(std::memory_order_relaxed))
            return VALUE_ZERO;

        if (is_decisive(value))
        {
            if (is_win(value))
                bestWinMate = std::min(bestWinMate, value);
            else if (is_loss(value))
                bestLossMate = std::max(bestLossMate, value);
        }
        else
            allDecisive = false;

        probabilitySamples.emplace_back(-int(value), count);
    }

    const auto& model = networks[numaAccessToken].big.model();
    if (model.probability_complete())
    {
        const auto parentAggregate =
          model.aggregate_probability(probabilitySamples, configured_aggressive_level(options));
        return Value(-parentAggregate);
    }

    if (allDecisive)
    {
        if (bestWinMate != VALUE_MATE)
            return bestWinMate;
        return bestLossMate;
    }

    double winrateSum = 0.0;
    for (const auto& [parentValue, count] : probabilitySamples)
        winrateSum += flip_score_to_winrate(Value(-parentValue)) * count;

    return flip_winrate_to_score(winrateSum / total);
}


template<NodeType nodeType, bool UseReveal>
Value Search::Worker::flip_search(
  Position& pos, Stack* ss, Value alpha, Value beta, bool isQsearch, Depth depth, bool cutNode) {
    const Color flipColor = ~pos.side_to_move();

    Position::RestPieceList restPieces;
    const int               restPieceCount = pos.rest_pieces(flipColor, restPieces);

    int total = 0;
    for (int i = 0; i < restPieceCount; ++i)
    {
        const auto& [piece, num] = restPieces[i];
        total += num;
    }

    assert(total != 0);

    if (restPieceCount == 0)
        return VALUE_DRAW;

    auto better_flip_branch = [](const auto& lhs, const auto& rhs) {
        if (lhs.second != rhs.second)
            return lhs.second > rhs.second;

        return PieceValue[lhs.first] > PieceValue[rhs.first];
    };

    for (int i = 1; i < restPieceCount; ++i)
    {
        auto branch = restPieces[i];
        int  j      = i;
        while (j > 0 && better_flip_branch(branch, restPieces[j - 1]))
        {
            restPieces[j] = restPieces[j - 1];
            --j;
        }
        restPieces[j] = branch;
    }

    const Square flipSq = (ss - 1)->currentMove.to_sq();
    DirtyPiece   dp     = accumulatorStack.latest_dirty_piece();
    ChanceBranchReduction branchReduction((ss - 1)->reduction);

    if (restPieceCount == 1)
    {
        Piece piece = restPieces[0].first;
        branchReduction.restore();

        accumulatorStack.pop();
        Piece flipped_piece = pos.do_flip(flipSq, piece, &dp, &tt);
        accumulatorStack.push(dp, pos);

        Value value;

        if (isQsearch)
            value = qsearch<nodeType, UseReveal>(pos, ss, alpha, beta);
        else
            value = search<nodeType, UseReveal>(pos, ss, alpha, beta, depth, cutNode);

        pos.undo_flip(flipSq, flipped_piece);
        return value;
    }

    bool                             all_decisive   = true;
    Value                            best_win_mate  = VALUE_MATE;
    Value                            best_loss_mate = -VALUE_MATE;
    std::vector<std::pair<int, int>> probabilitySamples;
    probabilitySamples.reserve(restPieceCount);

    for (int i = 0; i < restPieceCount; ++i)
    {
        auto& [piece, num] = restPieces[i];
        branchReduction.restore();
        accumulatorStack.pop();
        Piece flipped_piece = pos.do_flip(flipSq, piece, &dp, &tt);
        accumulatorStack.push(dp, pos);

        Value value;

        if (isQsearch)
            value = qsearch<nodeType, UseReveal>(pos, ss, alpha, beta);
        else
            value = search<nodeType, UseReveal>(pos, ss, alpha, beta,
                                                chance_branch_depth(depth, i), cutNode);

        pos.undo_flip(flipSq, flipped_piece);

        if (threads.stop.load(std::memory_order_relaxed))
            return VALUE_ZERO;

        if (is_decisive(value))
        {
            if (is_win(value))
                best_win_mate = std::min(best_win_mate, value);
            else if (is_loss(value))
                best_loss_mate = std::max(best_loss_mate, value);
        }
        else
            all_decisive = false;

        // The child search reports the child side's score. Convert every
        // sample to the parent perspective before applying the non-linear
        // score/mass lookup tables.
        probabilitySamples.emplace_back(-int(value), num);
    }

    const auto& model = networks[numaAccessToken].big.model();
    if (model.probability_complete())
    {
        const auto parentAggregate =
          model.aggregate_probability(probabilitySamples, configured_aggressive_level(options));
        return Value(-parentAggregate);
    }

    if (all_decisive)
    {
        if (best_win_mate != VALUE_MATE)
            return best_win_mate;
        else
            return best_loss_mate;
    }

    double winrateSum = 0.0;
    for (const auto& [parentValue, count] : probabilitySamples)
        winrateSum += flip_score_to_winrate(Value(-parentValue)) * count;
    double expectedWinrate = winrateSum / total;
    return flip_winrate_to_score(expectedWinrate);
}


Depth Search::Worker::reduction(bool i, Depth d, int mn, int delta) const {
    int reductionScale = reductions[d] * reductions[mn];
    return reductionScale - delta * 1333 / rootDelta + !i * reductionScale * 122 / 246 + 2378;
}

// elapsed() returns the time elapsed since the search started. If the
// 'nodestime' option is enabled, it will return the count of nodes searched
// instead. This function is called to check whether the search should be
// stopped based on predefined thresholds like time limits or nodes searched.
//
// elapsed_time() returns the actual time elapsed since the start of the search.
// This function is intended for use only when printing PV outputs, and not used
// for making decisions within the search algorithm itself.
TimePoint Search::Worker::elapsed() const {
    return main_manager()->tm.elapsed([this]() { return threads.nodes_searched(); });
}

TimePoint Search::Worker::elapsed_time() const { return main_manager()->tm.elapsed_time(); }

Value Search::Worker::evaluate(const Position& pos) {
    return Eval::evaluate(networks[numaAccessToken], pos, accumulatorStack, refreshTable,
                          optimism[pos.side_to_move()]);
}

int Search::Worker::reveal_bonus(const Position&                 pos,
                                 const Reveal::QuietMoveContext& quietContext) {
    if (!quietContext.eligible || !Reveal::quiet_bonus_enabled(revealParameters))
        return 0;

    return Reveal::quiet_bonus(
      revealParameters,
      Reveal::make_quiet_features(pos, quietContext.safety));
}

namespace {
// Adjusts a mate from "plies to mate from the root" to
// "plies to mate from the current position". Standard scores are unchanged.
// The function is called before storing a value in the transposition table.
Value value_to_tt(Value v, int ply) { return is_win(v) ? v + ply : is_loss(v) ? v - ply : v; }


// Inverse of value_to_tt(): it adjusts a mate score from the transposition
// table (which refers to the plies to mate/be mated from current position) to
// "plies to mate/be mated from the root". However, to avoid potentially false
// mate scores related to the 60 moves rule and the graph history interaction,
// we return the highest non-mate score instead.
Value value_from_tt(Value v, int ply, int r40c) {

    if (!is_valid(v))
        return VALUE_NONE;

    // Handle win
    if (is_win(v))
        // Downgrade a potentially false mate score
        return VALUE_MATE - v > 80 - r40c ? VALUE_MATE_IN_MAX_PLY - 1 : v - ply;

    // Handle loss
    if (is_loss(v))
        // Downgrade a potentially false mate score.
        return VALUE_MATE + v > 80 - r40c ? VALUE_MATED_IN_MAX_PLY + 1 : v + ply;

    return v;
}


// Adds current move and appends child pv[]
void update_pv(Move* pv, Move move, const Move* childPv) {

    for (*pv++ = move; childPv && *childPv != Move::none();)
        *pv++ = *childPv++;
    *pv = Move::none();
}


// Updates stats at the end of search() when a bestMove is found
void update_all_stats(const Position& pos,
                      Stack*          ss,
                      Search::Worker& workerThread,
                      Move            bestMove,
                      Square          prevSq,
                      SearchedList&   quietsSearched,
                      SearchedList&   capturesSearched,
                      Depth           depth,
                      Move            ttMove,
                      int             moveCount) {

    CapturePieceToHistory& captureHistory = workerThread.captureHistory;
    Piece                  movedPiece     = pos.moved_piece(bestMove);
    PieceType              capturedPiece;

    int bonus = std::min(144 * depth - 106, 1803) + 273 * (bestMove == ttMove);
    int malus = std::min(1012 * depth - 213, 2437) - 31 * moveCount;

    if (!pos.capture(bestMove))
    {
        update_quiet_histories(pos, ss, workerThread, bestMove, bonus * 1077 / 1024);

        // Decrease stats for all non-best quiet moves
        for (Move move : quietsSearched)
            update_quiet_histories(pos, ss, workerThread, move, -malus * 1555 / 1024);
    }
    else
    {
        // Increase stats for the best move in case it was a capture move
        capturedPiece = type_of(pos.piece_on(bestMove.to_sq()));
        captureHistory[movedPiece][bestMove.to_sq()][capturedPiece] << bonus * 1264 / 1024;
    }

    // Extra penalty for a quiet early move that was not a TT move in
    // previous ply when it gets refuted.
    if (prevSq != SQ_NONE && ((ss - 1)->moveCount == 1 + (ss - 1)->ttHit) && !pos.captured_piece())
        update_continuation_histories(ss - 1, pos.piece_on(prevSq), prevSq, -malus * 681 / 1024);

    // Decrease stats for all non-best capture moves
    for (Move move : capturesSearched)
    {
        movedPiece    = pos.moved_piece(move);
        capturedPiece = type_of(pos.piece_on(move.to_sq()));
        captureHistory[movedPiece][move.to_sq()][capturedPiece] << -malus * 1184 / 1024;
    }
}


// Updates histories of the move pairs formed by moves
// at ply -1, -2, -3, -4, and -6 with current move.
void update_continuation_histories(Stack* ss, Piece pc, Square to, int bonus) {
    static constexpr std::array<ConthistBonus, 6> conthist_bonuses = {
      {{1, 1028}, {2, 583}, {3, 282}, {4, 529}, {5, 130}, {6, 501}}};

    for (const auto [i, weight] : conthist_bonuses)
    {
        // Only update the first 2 continuation histories if we are in check
        if (ss->inCheck && i > 2)
            break;
        if (((ss - i)->currentMove).is_ok())
            (*(ss - i)->continuationHistory)[pc][to] << bonus * weight / 1024;
    }
}

// Updates move sorting heuristics

void update_quiet_histories(
  const Position& pos, Stack* ss, Search::Worker& workerThread, Move move, int bonus) {

    Color us = pos.side_to_move();
    workerThread.mainHistory[us][move.from_to()] << bonus;  // Untuned to prevent duplicate effort

    if (ss->ply < LOW_PLY_HISTORY_SIZE)
        workerThread.lowPlyHistory[ss->ply][move.from_to()] << bonus * 839 / 1024;

    update_continuation_histories(ss, pos.moved_piece(move), move.to_sq(),
                                  bonus * (bonus > 0 ? 1064 : 824) / 1024);

    int pIndex = pawn_structure_index(pos);
    workerThread.pawnHistory[pIndex][pos.moved_piece(move)][move.to_sq()]
      << bonus * (bonus > 0 ? 754 : 460) / 1024;
}

}

// Used to print debug info and, more importantly, to detect
// when we are out of available time and thus stop the search.
void SearchManager::check_time(Search::Worker& worker) {
    if (--callsCnt > 0)
        return;

    // When using nodes, ensure checking rate is not lower than 0.1% of nodes
    // Check often enough for the one-second fixed movetime used by the
    // tuning harness.  The old 512-node interval was too coarse in reveal and
    // qsearch-heavy positions and produced 300-700 ms overruns.
    callsCnt = worker.limits.nodes ? std::min(64, std::max(1, int(worker.limits.nodes / 1024))) : 64;

    static TimePoint lastInfoTime = now();

    TimePoint elapsed = tm.elapsed([&worker]() { return worker.threads.nodes_searched(); });
    TimePoint tick    = worker.limits.startTime + elapsed;

    if (tick - lastInfoTime >= 1000)
    {
        lastInfoTime = tick;
        dbg_print();
    }

    // We should not stop pondering until told so by the GUI
    if (ponder)
        return;

    if (
      // Later we rely on the fact that we can at least use the mainthread previous
      // root-search score and PV in a multithreaded environment to prove mated-in scores.
      ((worker.limits.use_time_management() && (elapsed > tm.maximum() || stopOnPonderhit))
          || (worker.limits.movetime && elapsed >= worker.limits.movetime)
          || (worker.limits.nodes && worker.threads.nodes_searched() >= worker.limits.nodes)))
        worker.threads.stop = worker.threads.abortedSearch = true;
}

void SearchManager::pv(const Search::Worker&     worker,
                       const ThreadPool&         threads,
                       const TranspositionTable& tt,
                       Depth                     depth) const {

    const auto  nodes     = threads.nodes_searched();
    const auto& rootMoves = worker.rootMoves;
    const auto& pos       = worker.rootPos;
    size_t      pvIdx     = worker.pvIdx;
    size_t      multiPV   = std::min(size_t(worker.options["MultiPV"]), rootMoves.size());

    for (size_t i = 0; i < multiPV; ++i)
    {
        bool updated = rootMoves[i].score != -VALUE_INFINITE;

        if (depth == 1 && !updated && i > 0)
            continue;

        Depth d = updated ? depth : std::max(1, depth - 1);
        Value v = updated ? rootMoves[i].uciScore : rootMoves[i].previousScore;

        if (v == -VALUE_INFINITE)
            v = VALUE_ZERO;

        std::string pv;
        Position    tempPos;
        // Position retains a pointer to its current state. Keep every state
        // alive for the full PV walk so a later move cannot alias tempPos.st.
        std::deque<StateInfo> pvStates;
        pvStates.emplace_back();
        tempPos.set(pos, &pvStates.back());

        for (Move m : rootMoves[i].pv)
        {
            pv += UCIEngine::move(m);

            if (tempPos.move_dark(m))
                break;

            pvStates.emplace_back();
            tempPos.do_move(m, pvStates.back());

            pv += " ";
        }

        // Remove last whitespace
        if (!pv.empty() && pv.back() == ' ')
            pv.pop_back();

        auto wdl   = worker.options["UCI_ShowWDL"] ? UCIEngine::wdl(v, pos) : "";
        auto bound = rootMoves[i].scoreLowerbound
                     ? "lowerbound"
                     : (rootMoves[i].scoreUpperbound ? "upperbound" : "");

        InfoFull info;

        info.depth    = d;
        info.selDepth = rootMoves[i].selDepth;
        info.multiPV  = i + 1;
        info.score    = {v, pos};
        info.wdl      = wdl;

        if (i == pvIdx && updated)  // previous-scores are exact
            info.bound = bound;

        TimePoint time = std::max(TimePoint(1), tm.elapsed_time());
        info.timeMs    = time;
        info.nodes     = nodes;
        info.nps       = nodes * 1000 / time;
        info.tbHits    = 0;
        info.pv        = pv;
        info.hashfull  = tt.hashfull();

        updates.onUpdateFull(info);
    }
}

// Called in case we have no ponder move before exiting the search,
// for instance, in case we stop the search during a fail high at root.
// We try hard to have a ponder move to return to the GUI,
// otherwise in case of 'ponder on' we have nothing to think about.
bool RootMove::extract_ponder_from_tt(const TranspositionTable& tt,
                                      Position&                 pos,
                                      Color                     rootObserver) {

    StateInfo st;

    assert(pv.size() == 1);
    if (pv[0] == Move::none() || pos.move_dark(pv[0]))
        return false;

    pos.do_move(pv[0], st, &tt);

    auto [ttHit, ttData, ttWriter] = tt.probe(observer_tt_key(pos.key(), rootObserver));
    if (ttHit)
    {
        if (MoveList<LEGAL>(pos).contains(ttData.move))
            pv.push_back(ttData.move);
    }

    pos.undo_move(pv[0]);
    return pv.size() > 1;
}


}  // namespace Stockfish
